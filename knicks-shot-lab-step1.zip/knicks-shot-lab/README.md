# Knicks Shot Lab — Step 1

A GitHub Pages-friendly, standalone basketball shot chart demo.

## Play
- **B**: Move left
- **C**: Move right
- **A**: Shoot
- The on-screen buttons work too.
- Shot chances are game settings, not actual NBA stats.

## Run
Open `index.html` in a browser, or publish the repository using GitHub Pages (Settings > Pages > Deploy from a branch > main > / (root)).

## Architecture
In Step 1 the browser simulates all controls and probability. It does **not** connect to the Arduino or Adafruit IO yet.

Future: Arduino Uno R4 WiFi + Modulino Buttons controls the game; Arduino evaluates shot probability and triggers Modulino Buzzer, and publishes compact events to Adafruit IO. Website consumes events via `window.applyKnicksEvent({id, event, position, result})`, making the Arduino the source of truth and avoiding duplicate random draws. Event IDs help avoid duplicate processing. Because Adafruit IO free accounts have a 30 data points/minute publish limit, later firmware should coalesce rapid MOVE events and publish position sparingly.

## Files
- `index.html` — markup and SVG court
- `style.css` — visual design and layout
- `script.js` — controls, demo probabilities, stats, future event hook

Never commit Wi-Fi passwords or Adafruit IO secret keys to a public repository.
