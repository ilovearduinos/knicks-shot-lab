"use strict";

// Demo probabilities are made-up game settings, NOT real NBA player statistics.
const spots = [
  {name: "Left Corner", chance: 0.38, x: 63, y: 292},
  {name: "Left Wing", chance: 0.36, x: 150, y: 370},
  {name: "Top of Key", chance: 0.40, x: 300, y: 400},
  {name: "Right Wing", chance: 0.36, x: 450, y: 370},
  {name: "Right Corner", chance: 0.38, x: 537, y: 292}
];

let selected = 2;
let shots = [];
let streak = 0;
let lastEventId = -1;
const $ = (id) => document.getElementById(id);
const svgNS = "http://www.w3.org/2000/svg";

function render() {
  document.querySelectorAll(".shooting-spot").forEach((node, index) => {
    node.classList.toggle("active", index === selected);
  });
  const spot = spots[selected];
  $("shot-name").textContent = spot.name;
  $("spot-label").textContent = spot.name.toUpperCase();
  $("shot-chance").textContent = `${Math.round(spot.chance * 100)}% make chance (demo)`;
  const makes = shots.filter(s => s.made).length;
  $("attempts").textContent = shots.length;
  $("makes").textContent = makes;
  $("percentage").textContent = shots.length ? `${Math.round(100 * makes / shots.length)}%` : "0%";
  $("points").textContent = makes * 3;
  $("streak").textContent = streak;

  const markers = $("shot-markers");
  markers.replaceChildren();
  shots.forEach(s => {
    const spot = spots[s.position];
    const circle = document.createElementNS(svgNS, "circle");
    circle.setAttribute("cx", spot.x + s.jitterX);
    circle.setAttribute("cy", spot.y + s.jitterY);
    circle.setAttribute("r", "6");
    circle.setAttribute("fill", s.made ? "#2dc77e" : "#ef5454");
    circle.setAttribute("stroke", "#fff");
    circle.setAttribute("stroke-width", "1.5");
    markers.append(circle);
  });

  const list = $("recent-shots");
  list.replaceChildren();
  if (shots.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No shots yet. Take your first!";
    list.append(li);
  }
  shots.slice(-5).reverse().forEach(s => {
    const li = document.createElement("li");
    const name = document.createElement("span");
    name.textContent = spots[s.position].name;
    const result = document.createElement("strong");
    result.textContent = s.made ? "+3 MAKE" : "MISS";
    result.className = s.made ? "shot-make" : "shot-miss";
    li.append(name, result);
    list.append(li);
  });
}

function feedback(text, type = "") {
  const el = $("feedback");
  el.textContent = text;
  el.className = "feedback " + type;
}
function move(delta) {
  selected = Math.max(0, Math.min(spots.length - 1, selected + delta));
  feedback(`Moved to ${spots[selected].name}`);
  render();
}
function recordShot(made, position = selected) {
  selected = position;
  // Small offsets keep repeated makes/misses visible instead of overlapping exactly.
  const jitterX = ((shots.length * 17) % 25) - 12;
  const jitterY = ((shots.length * 11) % 21) - 10;
  shots.push({position, made, jitterX, jitterY});
  streak = made ? streak + 1 : 0;
  feedback(made ? "BUCKET! +3 POINTS" : "NO GOOD! Try again.", made ? "make" : "miss");
  render();
}
function demoShoot() {
  const made = Math.random() < spots[selected].chance;
  recordShot(made);
}

// Later, Adafruit IO events will call this function. Arduino will be the
// source of truth for shot outcomes once connected; no second random roll.
// Example: window.applyKnicksEvent({id: 42, event:"SHOT", position:2, result:"MAKE"})
window.applyKnicksEvent = function(data) {
  if (!data || !Number.isInteger(data.id) || data.id <= lastEventId) return;
  if (!Number.isInteger(data.position) || data.position < 0 || data.position >= spots.length) return;
  if (data.event === "MOVE") {
    lastEventId = data.id;
    selected = data.position;
    feedback(`Moved to ${spots[selected].name}`);
    render();
  } else if (data.event === "SHOT" && ["MAKE", "MISS"].includes(data.result)) {
    lastEventId = data.id;
    recordShot(data.result === "MAKE", data.position);
  }
};

$("move-left").addEventListener("click", () => move(-1));
$("move-right").addEventListener("click", () => move(1));
$("shoot").addEventListener("click", demoShoot);
$("reset").addEventListener("click", () => {
  shots = []; streak = 0; selected = 2;
  feedback("New session! Press A to shoot.");
  render();
});
document.addEventListener("keydown", e => {
  if (e.repeat || e.altKey || e.ctrlKey || e.metaKey) return;
  const key = e.key.toLowerCase();
  if (key === "b" || key === "arrowleft") move(-1);
  if (key === "c" || key === "arrowright") move(1);
  if (key === "a" || key === " ") { e.preventDefault(); demoShoot(); }
});
render();
